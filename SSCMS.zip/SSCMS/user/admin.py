from django.contrib import admin
from .models import Student,Teacher

admin.site.register(Student)
admin.site.register(Teacher)
